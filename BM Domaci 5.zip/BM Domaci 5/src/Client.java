import javax.crypto.Cipher;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class Client {

    public Client() throws Exception{
        Socket socket = new Socket("localhost", 2024);

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader tin = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()),true);

        System.out.println(in.readLine());

        String publicKeyBase64 = in.readLine();
        byte[] publicKeyBytes = Base64.getDecoder().decode(publicKeyBase64);

        while (true) {
            System.out.println("Unesi tekst");
            String poruka = tin.readLine();
            String enkriptovano = enkriptujRSA(poruka, publicKeyBytes);
            out.println(enkriptovano);
            if(poruka.equals("EXIT")){
                break;
            }
        }
        socket.close();
    }

    public String enkriptujRSA(String poruka, byte[] publicKeyBytes) throws Exception {
        byte[] porukaBajt = poruka.getBytes();

        // Pretvaranje byteArray publicKey u PublicKey objekat
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);
        PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);

        // Inicijalizacija Cipher objekta sa javnim ključem
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);

        // Enkripcija poruke
        byte[] enkriptBajt = cipher.doFinal(porukaBajt);

        // Kodiranje enkriptovane poruke u Base64 format
        Base64.Encoder encoder = Base64.getEncoder();
        String enkod = encoder.encodeToString(enkriptBajt);

        return enkod;
    }

    public static void main(String[] args) throws Exception {
        new Client();
    }
}