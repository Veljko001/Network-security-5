import javax.crypto.Cipher;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

public class Server {



    public Server() throws Exception{
        ServerSocket serverSocket = new ServerSocket(2024);

        while (true){
            Socket socket = serverSocket.accept();

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedReader tin = new BufferedReader(new InputStreamReader(System.in));
            PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()),true);

            out.println("Dobrodosao");

            KeyPair keyPair = generisiRSAKljuc();

            PrivateKey privateKey = keyPair.getPrivate();
            PublicKey publicKey = keyPair.getPublic();

            byte[] publicKeyBytes = publicKey.getEncoded();
            String publicKeyBase64 = Base64.getEncoder().encodeToString(publicKeyBytes);
            out.println(publicKeyBase64);
            while (true) {
                String enkPoruka = in.readLine();
                System.out.println(enkPoruka);
                String poruka = dekriptujRSA(enkPoruka, privateKey);
                System.out.println(poruka);
                if(poruka.equals("EXIT")) {
                    System.out.println("Komunikacija je prekinuta");
                    break;
                }
            }
            socket.close();

        }


    }

    private KeyPair generisiRSAKljuc() throws Exception{
        KeyPairGenerator keyGenerator = KeyPairGenerator.getInstance("RSA");
        keyGenerator.initialize(1024); //2048

        KeyPair keyPair = keyGenerator.generateKeyPair();

        return keyPair;
    }

    public String dekriptujRSA(String enPoruka, PrivateKey privateKey) throws Exception{
        Base64.Decoder decoder =  Base64.getDecoder();
        byte[] enPorukaBajt = decoder.decode(enPoruka);

        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] dekPorukaBajt = cipher.doFinal(enPorukaBajt);

        return new String(dekPorukaBajt);
    }



    public static void main(String[] args) throws Exception {
        new Server();
    }
}